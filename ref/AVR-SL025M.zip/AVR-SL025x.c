////////////////////////////////////////////////////////////
//Test SL025x
//AVR C source code
//ATmega16(7.3728MHz) + EWAVR 5.20
////////////////////////////////////////////////////////////   
#include <ioavr.h>
#include <intrinsics.h>
#include <avr_macros.h>
#include <iomacro.h>
#include <string.h>

//============================================
//  oscillator define
//============================================
#define OSC 7372800L

//============================================
//  Uart bound define
//============================================
#define  BOUND4800         4800
#define  BOUND9600         9600
#define  BOUND14400        14400
#define  BOUND19200        19200
#define  BOUND28800        28800
#define  BOUND38400        38400
#define  BOUND57600        57600
#define  BOUND115200       115200

//============================================
//  Pin define
//============================================
#define CARDIN PIND_Bit2

//============================================
// Uart Status define
//============================================
#define UARTSTATUS_FREE   0
#define UARTSTATUS_TX     1
#define UARTSTATUS_TXSUCC 2
#define UARTSTATUS_RXSUCC 3
#define UARTSTATUS_RXERR  4

//============================================
//  global variable define
//============================================
unsigned char g_cCardType;
unsigned long int g_iTimer;
unsigned char g_bOverTime;
unsigned char g_cUartTxCnt;
unsigned char g_cUartTxDataLen;
unsigned char *g_pUartTxDat;
unsigned char g_cUartTxCheckSum;
unsigned char g_cUartRxCnt;
unsigned char g_cUartRxBuf[60];
unsigned char g_cUartStatus;

//============================================
//  Command List, preamble + length + command 
//============================================
const unsigned char SelectCard[]       ={0xBA,0x02,0x01 };       
const unsigned char LoginSector0[]     ={0xBA,0x0A,0x02,0x00,0xAA,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};  
const unsigned char LoginSector1[]     ={0xBA,0x0A,0x02,0x01,0xAA,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
const unsigned char ReadBlock1[]       ={0xBA,0x03,0x03,0x01};                                     
const unsigned char WriteBlock1[]      ={0xBA,0x13,0x04,0x01,0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xAA,0xBB,0xCC,0xDD,0xEE,0xFF};                                
const unsigned char ReadValue[]        ={0xBA,0x03,0x05,0x05};  
const unsigned char InitializeValue[]  ={0xBA,0x07,0x06,0x04,0x00,0x00,0x00,0x01};                                
const unsigned char IncrementValue[]   ={0xBA,0x07,0x08,0x04,0x00,0x00,0x00,0x20};                                
const unsigned char DecrementValue[]   ={0xBA,0x07,0x09,0x04,0x03,0x00,0x00,0x00};                                          
const unsigned char CopyValue[]        ={0xBA,0x04,0x0A,0x04,0x05};
const unsigned char ReadULPage5[]      ={0xBA,0x03,0x10,0x05};                                          
const unsigned char WriteULPage5[]     ={0xBA,0x07,0x11,0x05,0x11,0x22,0x33,0x44};
const unsigned char TurnOnRedLed[]     ={0xBA,0x03,0x40,0x01};     
const unsigned char TurnOffRedLed[]    ={0xBA,0x03,0x40,0x00};             

//============================================
//  procedure define
//============================================
void Init_Hardware();
void Start_Time(unsigned long int ms);
void Stop_Time();
void UARTISR_TX();
void SendBuf_UART(unsigned char *dat,unsigned char len);
void Test_SL025x();

void main()
{ 
  Init_Hardware();
  g_iTimer=0;
  while(1) Test_SL025x();
}

//============================================
//  initialize system hardware config
//  timer,uart,port
//============================================
void Init_Hardware()
{
  __disable_interrupt();
  DDRD=0x00;PORTD=0xff;
  TCCR0=0;
  TCNT0=184;
  TIMSK_TOIE0=1;
  TCCR0=0x05;
  UCSRB=0xd8;
  UBRRH=0x00;
  UBRRL=OSC/16/BOUND115200-1;
  g_cUartRxCnt=0;
  g_cUartStatus=UARTSTATUS_FREE;
  __enable_interrupt();
}

//============================================
//  start timer
//============================================
void Start_Time(unsigned long int ms)
{ 
  g_iTimer=ms;
  g_bOverTime=0;
}

//============================================
//  stop timer
//============================================
void Stop_Time()
{ 
  g_iTimer=0;
}

void UARTISR_TX()
{	
  unsigned char tmp;
  if(g_cUartTxCnt==g_cUartTxDataLen)
  {
    if(g_cUartStatus==UARTSTATUS_TX)
    {
      g_cUartStatus=UARTSTATUS_TXSUCC;
      g_cUartRxCnt=0;
      UDR=g_cUartTxCheckSum;
    }
  }
  else
  {
    tmp=g_pUartTxDat[g_cUartTxCnt];
    g_cUartTxCheckSum=g_cUartTxCheckSum^tmp;
    g_cUartTxCnt++;
    UDR=tmp;
  }
}

//============================================
//  send buffer by uart
//============================================
void SendBuf_UART(unsigned char *dat,unsigned char len)
{
  g_cUartStatus=UARTSTATUS_TX;
  g_pUartTxDat=dat;
  g_cUartTxDataLen=len;
  g_cUartTxCnt=0;
  g_cUartTxCheckSum=0;
  UARTISR_TX();
}

//============================================
//  timer0 overflow interrupt
//  10ms
//============================================
#pragma vector = TIMER0_OVF_vect
__interrupt void Timer0_ISR(void)
{
  TCNT0=184;
  if(g_iTimer!=0)
  {
    g_iTimer--;
    if(g_iTimer==0) g_bOverTime=1;
  }
}

//============================================
//  uart rx interrupt
//============================================
#pragma vector = USART_RXC_vect
__interrupt void UART_ISR_RXC(void)
{
  unsigned char CheckSum;
  unsigned char counter;
  g_cUartRxBuf[g_cUartRxCnt]=UDR;
  g_cUartRxCnt++;
  if(g_cUartRxCnt==g_cUartRxBuf[1]+2)
  {
    CheckSum=0;
    for(counter=0;counter<g_cUartRxCnt;counter++) CheckSum=CheckSum^g_cUartRxBuf[counter];
    if(CheckSum==0) g_cUartStatus=UARTSTATUS_RXSUCC;
    else g_cUartStatus=UARTSTATUS_RXERR;
  }
}

//============================================
//  uart tx interrupt
//============================================
#pragma vector = USART_TXC_vect
__interrupt void UART_ISR_TXC(void)
{
  UARTISR_TX();
}

void Test_SL025x()
{
  #define RCVCMD_SL025x g_cUartRxBuf[2]
  #define RCVSTA_SL025x g_cUartRxBuf[3]
  unsigned long int lPurseValue;
  g_cCardType=0xff;
  
  if(CARDIN!=0) return;
  
  SendBuf_UART((unsigned char *)(SelectCard),sizeof(SelectCard));	
  Start_Time(30);
  while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
  Stop_Time();	
  if((g_cUartStatus!=UARTSTATUS_RXSUCC)||(RCVCMD_SL025x!=0x01)||(RCVSTA_SL025x!=0)) return;
  g_cCardType=g_cUartRxBuf[g_cUartRxBuf[1]];
  
  switch(g_cCardType)
  {
    case 1:    //Mifare 1k 4 BYTE UID
    case 2:    //Mifare 1k 7 BYTE UID
    case 4:    //Mifare 4k 4 BYTE UID
    case 5:    //Mifare 4k 7 BYTE UID 
      //Verify password of sector0   
      SendBuf_UART((unsigned char *)(LoginSector0),sizeof(LoginSector0));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();	
      if((g_cUartStatus!=UARTSTATUS_RXSUCC)||(RCVCMD_SL025x!=0x02)||(RCVSTA_SL025x!=0x02)) return;
  
      //Write data to block1			
      SendBuf_UART((unsigned char *)(WriteBlock1),sizeof(WriteBlock1));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();	
      if((g_cUartStatus!=UARTSTATUS_RXSUCC)||(RCVCMD_SL025x!=0x04)||(RCVSTA_SL025x!=0)) return;
      if(memcmp(&WriteBlock1[4],&g_cUartRxBuf[4],16)!=0) return;
  
      //Read data from block1
      SendBuf_UART((unsigned char *)(ReadBlock1),sizeof(ReadBlock1));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();	
      if((g_cUartStatus!=UARTSTATUS_RXSUCC)||(RCVCMD_SL025x!=0x03)||(RCVSTA_SL025x!=0)) return;
      if(memcmp(&WriteBlock1[4],&g_cUartRxBuf[4],16)!=0) return;
  
      //Verify password of sector1
      SendBuf_UART((unsigned char *)(LoginSector1),sizeof(LoginSector1));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();	
      if((g_cUartStatus!=UARTSTATUS_RXSUCC)||(RCVCMD_SL025x!=0x02)||(RCVSTA_SL025x!=0x02)) return;
  
      //Initialize block4 to one purse, and value = 0x01000000
      SendBuf_UART((unsigned char *)(InitializeValue),sizeof(InitializeValue));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();	
      if((g_cUartStatus!=UARTSTATUS_RXSUCC)||(RCVCMD_SL025x!=0x06)||(RCVSTA_SL025x!=0)) return;
      if(memcmp(&InitializeValue[4],&g_cUartRxBuf[4],4)!=0) return;
      
      //Increment
      SendBuf_UART((unsigned char *)(IncrementValue),sizeof(IncrementValue));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();	
      if((g_cUartStatus!=UARTSTATUS_RXSUCC)||(RCVCMD_SL025x!=0x08)||(RCVSTA_SL025x!=0)) return;
      
      //Decrement
      SendBuf_UART((unsigned char *)(DecrementValue),sizeof(DecrementValue));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();	
      if((g_cUartStatus!=UARTSTATUS_RXSUCC)||(RCVCMD_SL025x!=0x09)||(RCVSTA_SL025x!=0)) return;
      
      //Backup purse to blcok5
      SendBuf_UART((unsigned char *)(CopyValue),sizeof(CopyValue));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();	
      if((g_cUartStatus!=UARTSTATUS_RXSUCC)||(RCVCMD_SL025x!=0x0a)||(RCVSTA_SL025x!=0)) return;
      
      //Read purse value from blcok5			   
      SendBuf_UART((unsigned char *)(ReadValue),sizeof(ReadValue));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();	
      if((g_cUartStatus!=UARTSTATUS_RXSUCC)||(RCVCMD_SL025x!=0x05)||(RCVSTA_SL025x!=0)) return;
      
      //Check value	 
      lPurseValue=g_cUartRxBuf[7];
      lPurseValue=(lPurseValue<<8)+g_cUartRxBuf[6];
      lPurseValue=(lPurseValue<<8)+g_cUartRxBuf[5];
      lPurseValue=(lPurseValue<<8)+g_cUartRxBuf[4];
      if(lPurseValue!=0x01000000+0x20000000-0x00000003) return;
      
      //Glare Red_Led to indicate working ok
      SendBuf_UART((unsigned char *)(TurnOnRedLed),sizeof(TurnOnRedLed));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();
      Start_Time(30);
      while(g_bOverTime==0);
      Stop_Time();
      SendBuf_UART((unsigned char *)(TurnOffRedLed),sizeof(TurnOffRedLed));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();
      break;
    

    case 3:   //Mifare Ultralight
      SendBuf_UART((unsigned char *)(WriteULPage5),sizeof(WriteULPage5));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();	
      if((g_cUartStatus!=UARTSTATUS_RXSUCC)||(RCVCMD_SL025x!=0x11)||(RCVSTA_SL025x!=0)) return;
      SendBuf_UART((unsigned char *)(ReadULPage5),sizeof(ReadULPage5));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();	
      if((g_cUartStatus!=UARTSTATUS_RXSUCC)||(RCVCMD_SL025x!=0x10)||(RCVSTA_SL025x!=0)) return;
      if (memcmp(&WriteULPage5[4],&g_cUartRxBuf[4],4)!=0) return;
      
      //Glare Red_Led to indicate working ok
      SendBuf_UART((unsigned char *)(TurnOnRedLed),sizeof(TurnOnRedLed));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();
      Start_Time(30);
      while(g_bOverTime==0);
      Stop_Time();
      SendBuf_UART((unsigned char *)(TurnOffRedLed),sizeof(TurnOffRedLed));
      Start_Time(30);
      while((g_cUartStatus!=UARTSTATUS_RXERR)&&(g_cUartStatus!=UARTSTATUS_RXSUCC)&&(g_bOverTime==0));
      Stop_Time();
      break;
 

    default:
      break;
  }
}

